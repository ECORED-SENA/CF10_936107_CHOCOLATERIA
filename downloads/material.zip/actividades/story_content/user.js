function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6bdsL92vo3f":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

